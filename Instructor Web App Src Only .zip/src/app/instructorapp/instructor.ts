export class Instructor {
    instructorcode!:number;
	 name!:string;
	salary!:number;
	jobstartyear!:number;
	email!:string;
	trainerlocation!:string;
	
}
