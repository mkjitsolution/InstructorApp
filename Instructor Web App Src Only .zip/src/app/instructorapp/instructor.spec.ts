import { Instructor } from './instructor';

describe('Instructor', () => {
  it('should create an instance', () => {
    expect(new Instructor()).toBeTruthy();
  });
});
