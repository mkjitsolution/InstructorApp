import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'InstructorWebApp';
  footerMsg = " All Rights Reserved March 2021 @ Ashish Bansal"
}
