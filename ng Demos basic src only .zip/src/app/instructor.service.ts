import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InstructorService {

  constructor(private http:HttpClient) {

   }

   getWebData()
   {
     let url = 'http://localhost:9001/api/jpa/trainers';
     return this.http.get(url);
   }
}
