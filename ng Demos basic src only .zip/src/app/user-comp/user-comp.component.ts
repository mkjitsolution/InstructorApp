import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-comp',
  templateUrl: './user-comp.component.html',
  styleUrls: ['./user-comp.component.less']
})

export class UserCompComponent implements OnInit {

  username = 'Mike123';
  password = '123456';
  
  constructor() { }

  ngOnInit(): void {
  }

  checkUserLogin(usernameValue:string,passwordValue:string)
  {
    alert(usernameValue+" "+passwordValue);
  }
}
