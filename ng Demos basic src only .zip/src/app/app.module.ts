import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserCompComponent } from './user-comp/user-comp.component';
import {UsersModule} from './users/users.module';
import { BootStrapComponent2Component } from './boot-strap-component2/boot-strap-component2.component'


@NgModule({
  declarations: [
    AppComponent,
    UserCompComponent,
    BootStrapComponent2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UsersModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent,BootStrapComponent2Component]
})
export class AppModule { }
