import { Component } from '@angular/core';
import {InstructorService} from './instructor.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})



export class AppComponent {
  title = 'MKJ App';
  status = true;
  records: any = []

  constructor(private instructorService:InstructorService)
  {
    this.instructorService.getWebData().subscribe(
      records=>{
          console.warn(records);
          this.records = records;
      });
  }

  getTitle()
  {
    console.log('Welcome');
    return this.title+" My Angular";
  }

  student = {
    name : "rakesh",
    age : 20,
    marks : 858
  }

  arr = ['java','angular','react'];
   
  

}
