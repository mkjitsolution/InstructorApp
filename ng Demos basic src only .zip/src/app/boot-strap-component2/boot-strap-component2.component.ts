import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boot-strap-component2',
  templateUrl: './boot-strap-component2.component.html',
  styleUrls: ['./boot-strap-component2.component.less']
})
export class BootStrapComponent2Component implements OnInit {

  constructor() { 
    console.log(" bootstarp 2 ");
  }

  ngOnInit(): void {
  }

}
