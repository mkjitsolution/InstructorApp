import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BootStrapComponent2Component } from './boot-strap-component2.component';

describe('BootStrapComponent2Component', () => {
  let component: BootStrapComponent2Component;
  let fixture: ComponentFixture<BootStrapComponent2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BootStrapComponent2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BootStrapComponent2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
